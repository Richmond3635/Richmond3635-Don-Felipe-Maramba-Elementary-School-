<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2022 Online Student information system
                </div>

            </div>
        </div>
    </footer>