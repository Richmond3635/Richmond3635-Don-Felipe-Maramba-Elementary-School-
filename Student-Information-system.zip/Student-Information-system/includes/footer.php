<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2022 nline Student Information System
                </div>

            </div>
        </div>
    </footer>